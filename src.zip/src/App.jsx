function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Bem-vindo ao Estetix</h1>
      <p>Protótipo funcional carregado com sucesso!</p>
    </div>
  )
}

export default App
